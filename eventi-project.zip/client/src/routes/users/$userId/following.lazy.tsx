import { InfiniteScroll } from "@/features/shared/components/InfiniteScroll";
import { UserList } from "@/features/users/components/UserList";
import { UserFollowButton } from "@/features/users/components/UserFollowButton";
import { createLazyFileRoute } from "@tanstack/react-router";
import { trpc } from "@/router";

export const Route = createLazyFileRoute("/users/$userId/following")({
  component: UserFollowingPage,
});

function UserFollowingPage() {
  const { userId } = Route.useParams();
  const [{ pages }, followingQuery] =
    trpc.users.following.useSuspenseInfiniteQuery(
      { id: userId },
      {
        getNextPageParam: (lastPage) => lastPage.nextCursor,
      },
    );
  const totalFollowers = pages[0].followingCount;
  return (
    <main className="space-y-4">
      <h1 className="text-2xl font-bold">Followers ({totalFollowers})</h1>
      <InfiniteScroll onLoadMore={followingQuery.fetchNextPage}>
        <UserList
          users={pages.flatMap((page) => page.items)}
          isLoading={
            followingQuery.isFetchingNextPage || followingQuery.isLoading
          }
          rightComponent={(user) => (
            <UserFollowButton
              targetUserId={user.id}
              isFollowing={user.isFollowing}
            />
          )}
        />
      </InfiniteScroll>
    </main>
  );
}
